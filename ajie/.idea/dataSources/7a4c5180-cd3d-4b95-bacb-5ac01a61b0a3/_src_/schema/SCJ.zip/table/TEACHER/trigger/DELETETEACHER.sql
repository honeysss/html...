CREATE TRIGGER DELETETEACHER
AFTER DELETE
  ON TEACHER
FOR EACH ROW
  BEGIN
    update COURSE set tno = 'null' where tno = :old.tno;
  END;
/
