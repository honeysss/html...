CREATE TRIGGER TIMELIMIT
BEFORE INSERT OR UPDATE OR DELETE
  ON SCORE
  BEGIN
    if(to_char(sysdate, 'HH24:MI') not BETWEEN '11:00' and '18:00') THEN
     raise_application_error(-20004, '不能在这个时间段修改成绩');
    END IF;
  END;
/
