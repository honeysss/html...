CREATE TRIGGER INSERTSCORE1
BEFORE INSERT
  ON SCORE
FOR EACH ROW
  DECLARE
    courseName course.cname%TYPE ;
    BEGIN
    select cname into courseName from course where cno = :new.cno;
    if courseName = '英语' then
      raise_application_error(-20001, '该课程已经考试结束，不能添加成绩');
    END IF;
  END;
/
