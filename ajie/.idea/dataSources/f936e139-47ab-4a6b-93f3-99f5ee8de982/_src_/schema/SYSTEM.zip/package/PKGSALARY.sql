CREATE PACKAGE pkgsalary
IS
  FUNCTION funSalaryGrowthrate(v_school IN CHAR)
    RETURN NUMBER;
  PROCEDURE sp_updatesalary;
END;
/
