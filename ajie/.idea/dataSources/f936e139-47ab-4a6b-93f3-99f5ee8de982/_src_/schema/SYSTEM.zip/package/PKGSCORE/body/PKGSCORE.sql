CREATE PACKAGE BODY pkgScore
IS
  FUNCTION avgScore(p_cno IN CHAR)
    RETURN NUMBER
  AS
    v_grade NUMBER;
    BEGIN
      SELECT avg(grade)
      INTO v_grade
      FROM score
      WHERE cno = p_cno;
      RETURN (v_grade);
    END avgScore;
END;
/
