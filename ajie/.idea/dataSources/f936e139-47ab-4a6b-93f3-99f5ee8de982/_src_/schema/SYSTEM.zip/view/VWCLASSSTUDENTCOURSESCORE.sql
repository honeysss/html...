CREATE VIEW VWCLASSSTUDENTCOURSESCORE AS select student.sno,student.sname,student.ssex,student.sclass,course.cno,course.cname,score.grade from student,course,score where student.sclass='201236'
and student.sno = score.sno and course.cno = score.cno
/
