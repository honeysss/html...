CREATE VIEW VWAVGGRADESTUDENTSCORE AS select student.sno as 学号,student.sname as 姓名,avg(score.grade) as 平均分 from score,student
  where student.sno  = score.sno GROUP BY student.sno,student.sname ORDER BY avg(score.grade) DESC
/
