CREATE PROCEDURE updateSalary
AS
BEGIN
  UPDATE teacher
  SET salary = salary * 1.1 + 700
  WHERE school = '计算机学院' AND title = '教授';
  UPDATE teacher
  SET salary = salary * 1.1 + 300
  WHERE school = '计算机学院' AND title = '讲师';
  UPDATE teacher
  SET salary = salary * 1.09 + 700
  WHERE school = '通信学院';
  UPDATE teacher
  SET salary = salary * 1.05 + 500
  WHERE school = '数学学院';
  UPDATE teacher
  SET salary = salary * 1.05 + 500
  WHERE school = '外国语学院';
END;
/
