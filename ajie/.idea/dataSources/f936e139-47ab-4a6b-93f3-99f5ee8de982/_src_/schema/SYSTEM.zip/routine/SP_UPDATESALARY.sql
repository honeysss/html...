CREATE procedure sp_updatesalary
  as
    begin
      declare
        v_title char(12);
        v_school char(12);
        v_salary number;
        v_name char(12);
        v_growthrate number;
        cursor curTeacher
        is
          select title,school,salary, tname
          from teacher where salary is not null for update;
      begin
        open curTeacher;
        FETCH curTeacher into v_title, v_school,v_salary,v_name;
        while curTeacher%found loop
          v_growthrate := funSalaryGrowthrate(v_school);
          v_salary := v_salary * v_growthrate;
          if v_title='教授' then v_salary:= v_salary+700;
          end if;
          if v_title='副教授' then v_salary:= v_salary+500;
          end if;
          if v_title='讲师' then v_salary:= v_salary+300;
          end if;
          dbms_output.put_line('姓名' || v_name || ' 工资：'||v_salary);
          FETCH curTeacher into v_title, v_school,v_salary,v_name;
        end loop;
        close curTeacher;
      end;
    end ;
/
