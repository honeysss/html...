CREATE PROCEDURE teInfo
AS
  BEGIN
    DECLARE
      t_name   CHAR(8);
      t_salary FLOAT;
      CURSOR salary
      IS
        SELECT
          tname,
          salary
        FROM TEACHER;
    BEGIN
      OPEN salary;
      FETCH salary INTO t_name, t_salary;
      WHILE salary%FOUND
      LOOP
        dbms_output.put_line('姓名:' || t_name || '工资:' || t_salary);
        FETCH salary INTO t_name, t_salary;
      END LOOP;
      CLOSE salary;
    END;
  END ;
/
