CREATE procedure spSpecialityCnameAvg (Speciality in char, Cname in char, avg OUT NUMBER)
  AS
  BEGIN
    select avg(grade) into avg from student,score,course where cname = Cname and speciality = Speciality and score.cno = course.cno and score.sno = student.sno;
  END;
/
