CREATE function funSalaryGrowthrate(v_school in char)
    return number
  as
    v_salary number;
    begin
      if v_school='计算机学院' THEN v_salary:=1.1;
      end if;
      if v_school='通信学院' THEN v_salary:=1.09;
      end if;
      if v_school='数学学院' THEN v_salary:=1.05;
      end if;
      if v_school='外国语学院' THEN v_salary:=1.05;
      end if;
      RETURN(v_salary);
    end ;
/
