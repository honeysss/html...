CREATE TRIGGER STUANDTEA
AFTER DELETE
  ON TEACHER
FOR EACH ROW
  BEGIN
  update course set  tno = 'null' where tno = :old.tno;
END;
/
