CREATE PACKAGE pkgsalary
IS
  FUNCTION funSalaryGrowthrate(v_school IN CHAR)
    RETURN NUMBER;
  PROCEDURE sp_updatesalary;
END;
/
CREATE PACKAGE BODY pkgsalary
IS

  FUNCTION funSalaryGrowthrate(v_school IN CHAR)
    RETURN NUMBER
  AS
    v_salary NUMBER;
    BEGIN
      IF v_school = '计算机学院'
      THEN v_salary := 1.1;
      END IF;
      IF v_school = '通信学院'
      THEN v_salary := 1.09;
      END IF;
      IF v_school = '数学学院'
      THEN v_salary := 1.05;
      END IF;
      IF v_school = '外国语学院'
      THEN v_salary := 1.05;
      END IF;
      RETURN (v_salary);
    END;

  PROCEDURE sp_updatesalary
  AS
    BEGIN
      DECLARE
        v_title      CHAR(12);
        v_school     CHAR(12);
        v_salary     NUMBER;
        v_name       CHAR(12);
        v_growthrate NUMBER;
        CURSOR curTeacher
        IS
          SELECT
            title,
            school,
            salary,
            tname
          FROM teacher
          WHERE salary IS NOT NULL
          FOR UPDATE;
      BEGIN
        OPEN curTeacher;
        FETCH curTeacher INTO v_title, v_school, v_salary, v_name;
        WHILE curTeacher%FOUND LOOP
          v_growthrate := funSalaryGrowthrate(v_school);
          v_salary := v_salary * v_growthrate;
          IF v_title = '教授'
          THEN v_salary := v_salary + 700;
          END IF;
          IF v_title = '副教授'
          THEN v_salary := v_salary + 500;
          END IF;
          IF v_title = '讲师'
          THEN v_salary := v_salary + 300;
          END IF;
          dbms_output.put_line('姓名' || v_name || ' 工资：' || v_salary);
          FETCH curTeacher INTO v_title, v_school, v_salary, v_name;
        END LOOP;
        CLOSE curTeacher;
      END;
    END;
END;
/
