CREATE PACKAGE upSalary
AS
  FUNCTION updateSalary RETURN NUMBER;
  PROCEDURE teInfo;
END;
/
CREATE PACKAGE BODY upSalary
AS
  FUNCTION updateSalary
    RETURN NUMBER
  AS
    BEGIN
      UPDATE teacher
      SET salary = salary * 1.1 + 700
      WHERE school = '计算机学院' AND title = '教授';
      UPDATE teacher
      SET salary = salary * 1.1 + 300
      WHERE school = '计算机学院' AND title = '讲师';
      UPDATE teacher
      SET salary = salary * 1.09 + 700
      WHERE school = '通信学院';
      UPDATE teacher
      SET salary = salary * 1.05 + 500
      WHERE school = '数学学院';
      UPDATE teacher
      SET salary = salary * 1.05 + 500
      WHERE school = '外国语学院';
      RETURN 1;
    END;

  PROCEDURE teInfo
  AS
    BEGIN
      DECLARE
        t_name   CHAR(8);
        t_salary FLOAT;
        CURSOR salary
        IS
          SELECT
            tname,
            salary
          FROM TEACHER;
      BEGIN
        OPEN salary;
        FETCH salary INTO t_name, t_salary;
        WHILE salary%FOUND
        LOOP
          dbms_output.put_line('姓名:' || t_name || '工资:' || t_salary);
          FETCH salary INTO t_name, t_salary;
        END LOOP;
        CLOSE salary;
      END;
    END;
END;
/
