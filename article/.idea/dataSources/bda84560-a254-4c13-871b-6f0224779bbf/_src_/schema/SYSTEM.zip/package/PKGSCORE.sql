CREATE PACKAGE pkgScore
IS
  FUNCTION avgScore(p_cno IN CHAR)
    RETURN NUMBER;
END;
/
CREATE package body pkgScore
    is
    function avgScore(p_cno in char)
      return number
    AS
      v_grade number;
      BEGIN
        select avg(grade) into v_grade from score where cno = p_cno;
        return (v_grade);
        end avgScore;
      END;
/
