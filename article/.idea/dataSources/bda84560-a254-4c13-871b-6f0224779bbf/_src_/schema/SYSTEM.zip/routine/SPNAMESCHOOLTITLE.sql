CREATE procedure spNameSchoolTitle(t_no in char, t_name out char,t_title out char,t_school out char)
  AS
  BEGIN
    select tname into t_name from teacher where tno = t_no;
    select title into t_title from teacher where tno = t_no;
    select school into  t_school from teacher where tno = t_no;
  END;
/
