CREATE FUNCTION funAvgGrade(t_name in char, n_class in char)
  return NUMBER as result NUMBER;
  BEGIN
    select avg(score.grade) into result from teacher,score,student where teacher.tname = t_name  AND
                                                                        teacher.tno = course.tno and course.cno  = score.cno and
                                                                                student.sno = score.sno
    and student.sclass = n_class;
    RETURN (result);
  END;
/
