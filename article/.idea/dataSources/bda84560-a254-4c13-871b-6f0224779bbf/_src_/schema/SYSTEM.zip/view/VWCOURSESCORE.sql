CREATE VIEW VWCOURSESCORE AS select student.sno,course.cname,score.grade from student,score,course where student.sno = score.sno and course.cno = score.cno
/
